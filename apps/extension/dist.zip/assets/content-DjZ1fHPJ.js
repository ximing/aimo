let i=null,l=null,a=null,u=null;const r={primary:"#3b82f6",primaryHover:"#2563eb",background:{light:"#ffffff",dark:"#1f2937"},text:{light:"#374151",dark:"#f3f4f6"},border:{light:"#e5e7eb",dark:"#374151"},shadow:{light:"0 4px 12px rgba(0, 0, 0, 0.15)",dark:"0 4px 12px rgba(0, 0, 0, 0.4)"}};function w(){return window.matchMedia("(prefers-color-scheme: dark)").matches}function k(){const e=w();return{background:e?r.background.dark:r.background.light,text:e?r.text.dark:r.text.light,border:e?r.border.dark:r.border.light,shadow:e?r.shadow.dark:r.shadow.light}}function v(){const e=document.createElement("div");e.id="aimo-toolbar-container",l=e.attachShadow({mode:"closed"});const n=document.createElement("div");n.id="aimo-toolbar";const t=k(),o=document.createElement("style");return o.textContent=`
    #aimo-toolbar {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      background: ${t.background};
      border: 1px solid ${t.border};
      border-radius: 8px;
      box-shadow: ${t.shadow};
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      color: ${t.text};
      cursor: default;
      user-select: none;
      animation: aimo-fade-in 0.15s ease-out;
      z-index: 2147483647;
    }

    @keyframes aimo-fade-in {
      from {
        opacity: 0;
        transform: translateY(4px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    #aimo-toolbar.hidden {
      animation: aimo-fade-out 0.1s ease-in forwards;
    }

    @keyframes aimo-fade-out {
      from {
        opacity: 1;
        transform: translateY(0);
      }
      to {
        opacity: 0;
        transform: translateY(4px);
      }
    }

    .aimo-logo {
      width: 20px;
      height: 20px;
      flex-shrink: 0;
    }

    .aimo-divider {
      width: 1px;
      height: 16px;
      background: ${t.border};
      margin: 0 4px;
    }

    .aimo-save-btn {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 12px;
      background: ${r.primary};
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.15s ease;
    }

    .aimo-save-btn:hover {
      background: ${r.primaryHover};
    }

    .aimo-save-btn:active {
      transform: scale(0.98);
    }

    .aimo-save-btn svg {
      width: 14px;
      height: 14px;
    }

    .aimo-type-indicator {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 12px;
      color: ${t.text};
      opacity: 0.7;
    }

    .aimo-type-indicator svg {
      width: 14px;
      height: 14px;
    }
  `,l.appendChild(o),l.appendChild(n),e}function T(){return`<svg class="aimo-logo" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="24" height="24" rx="4" fill="${r.primary}"/>
    <path d="M7 12L10.5 15.5L17 9" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`}function S(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/>
    <polyline points="17 21 17 13 7 13 7 21"/>
    <polyline points="7 3 7 8 15 8"/>
  </svg>`}function E(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
    <line x1="16" y1="13" x2="8" y2="13"/>
    <line x1="16" y1="17" x2="8" y2="17"/>
    <polyline points="10 9 9 9 8 9"/>
  </svg>`}function I(){return`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
    <circle cx="8.5" cy="8.5" r="1.5"/>
    <polyline points="21 15 16 10 5 21"/>
  </svg>`}function C(){if(!l||!a)return;const e=l.getElementById("aimo-toolbar");if(!e)return;const n=a.type==="image",t=n?"图片":"文本",o=n?I():E(),s=n?"保存图片到 AIMO":"保存到 AIMO";e.innerHTML=`
    ${T()}
    <div class="aimo-type-indicator">
      ${o}
      <span>${t}</span>
    </div>
    <div class="aimo-divider"></div>
    <button class="aimo-save-btn" id="aimo-save-btn">
      ${S()}
      <span>${s}</span>
    </button>
  `;const m=e.querySelector("#aimo-save-btn");m&&m.addEventListener("click",M)}function p(e){if(!i)return;const n=8;let t=e.right+n-150,o=e.bottom+n;const s=200,m=50;t+s>window.innerWidth&&(t=window.innerWidth-s-16),t<16&&(t=16),o+m>window.innerHeight+window.scrollY?o=e.top+window.scrollY-m-n:o+=window.scrollY,i.style.cssText=`
    position: absolute;
    top: ${o}px;
    left: ${t}px;
    z-index: 2147483647;
  `}function g(){i||(i=v(),document.body.appendChild(i)),C(),u&&(clearTimeout(u),u=null)}function d(){if(!i||!l)return;const e=l.getElementById("aimo-toolbar");e&&e.classList.add("hidden"),u=window.setTimeout(()=>{i&&(i.remove(),i=null,l=null),a=null},100)}async function M(){if(!a)return;const e=a.type==="image";let n=null;e&&(n=$("正在上传图片..."));try{const t={type:"SAVE_TO_MEMO",data:a},o=await chrome.runtime.sendMessage(t);console.log("SAVE_TO_MEMO response:",o),n&&n.remove(),o?.success?(f("已保存到 AIMO","success"),d()):(console.error("Failed to save content:",o?.error),f(o?.error||"保存失败，请检查扩展配置","error"))}catch(t){n&&n.remove(),console.error("Error saving content:",t),f("保存失败，请检查网络连接","error")}}function f(e,n){const t=document.createElement("div");if(t.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 12px 20px;
    background: ${n==="error"?"#dc2626":"#16a34a"};
    color: white;
    border-radius: 8px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    font-weight: 500;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    z-index: 2147483647;
    animation: aimo-notification-slide-in 0.3s ease-out;
  `,t.textContent=e,!document.getElementById("aimo-notification-styles")){const o=document.createElement("style");o.id="aimo-notification-styles",o.textContent=`
      @keyframes aimo-notification-slide-in {
        from {
          transform: translateX(100%);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
      @keyframes aimo-notification-slide-out {
        from {
          transform: translateX(0);
          opacity: 1;
        }
        to {
          transform: translateX(100%);
          opacity: 0;
        }
      }
    `,document.head.appendChild(o)}document.body.appendChild(t),setTimeout(()=>{t.style.animation="aimo-notification-slide-out 0.3s ease-out",setTimeout(()=>{t.remove()},300)},3e3)}function $(e){const n=document.createElement("div");n.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 12px 20px;
    background: #3b82f6;
    color: white;
    border-radius: 8px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    font-weight: 500;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    z-index: 2147483647;
    animation: aimo-notification-slide-in 0.3s ease-out;
    display: flex;
    align-items: center;
    gap: 8px;
  `;const t=document.createElement("div");if(t.style.cssText=`
    width: 16px;
    height: 16px;
    border: 2px solid rgba(255,255,255,0.3);
    border-top-color: white;
    border-radius: 50%;
    animation: aimo-spin 0.8s linear infinite;
  `,document.getElementById("aimo-notification-styles")){const o=document.getElementById("aimo-notification-styles");o&&!o.textContent?.includes("aimo-spin")&&(o.textContent+=`
        @keyframes aimo-spin {
          to { transform: rotate(360deg); }
        }
      `)}else{const o=document.createElement("style");o.id="aimo-notification-styles",o.textContent=`
      @keyframes aimo-notification-slide-in {
        from {
          transform: translateX(100%);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
      @keyframes aimo-notification-slide-out {
        from {
          transform: translateX(0);
          opacity: 1;
        }
        to {
          transform: translateX(100%);
          opacity: 0;
        }
      }
      @keyframes aimo-spin {
        to { transform: rotate(360deg); }
      }
    `,document.head.appendChild(o)}return n.appendChild(t),n.appendChild(document.createTextNode(e)),document.body.appendChild(n),n}function h(){const e=window.getSelection();if(!e||e.rangeCount===0)return null;const n=e.getRangeAt(0);return n.collapsed?null:n.getBoundingClientRect()}function x(e){if(e.tagName==="IMG"){const o=e;if(o.src)return o.src}const t=window.getComputedStyle(e).backgroundImage;if(t&&t!=="none"){const o=t.match(/url\(["']?([^"')]+)["']?\)/);if(o?.[1])return o[1].startsWith("http")?o[1]:o[1].startsWith("//")?`${window.location.protocol}${o[1]}`:o[1].startsWith("/")?`${window.location.origin}${o[1]}`:`${window.location.href.substring(0,window.location.href.lastIndexOf("/")+1)}${o[1]}`}return null}function y(e){if(e.tagName==="IMG"){const t=e;return t.width>=50&&t.height>=50}const n=window.getComputedStyle(e);if(n.backgroundImage&&n.backgroundImage!=="none"){const t=e.getBoundingClientRect();return t.width>=50&&t.height>=50}return!1}function L(e){const n=e.target;if(n.closest("#aimo-toolbar-container"))return;let t=n,o=null;for(;t&&t!==document.body&&(o=x(t),!(o&&y(t)));)o=null,t=t.parentElement;o&&t&&(e.preventDefault(),e.stopPropagation(),b(t,o))}function b(e,n){const t=e.getBoundingClientRect();a={type:"image",content:n,sourceUrl:window.location.href,sourceTitle:document.title},g(),p(t)}let c=null;function B(e){const n=e.target;if(n.closest("#aimo-toolbar-container"))return;let t=n,o=null;for(;t&&t!==document.body&&(o=x(t),!(o&&y(t)));)o=null,t=t.parentElement;o&&t&&(c&&(clearTimeout(c),c=null),c=setTimeout(()=>{b(t,o)},300))}function O(e){e.target.closest("#aimo-toolbar-container")||(c&&(clearTimeout(c),c=null),a?.type==="image"&&d())}function z(e){if(!i)return;const n=e.target;if(i.contains(n))return;const t=window.getSelection();t&&t.toString().trim().length>0||e.target.tagName!=="IMG"&&d()}function H(){i&&a?.type==="text"&&d()}function R(e){e.target.closest("#aimo-toolbar-container")||setTimeout(()=>{const o=window.getSelection()?.toString().trim()||"";if(o.length>0){const s=h();s&&(a={type:"text",content:o,sourceUrl:window.location.href,sourceTitle:document.title},g(),p(s))}},50)}document.addEventListener("mouseup",R);document.addEventListener("click",L);document.addEventListener("mouseover",B,{passive:!0});document.addEventListener("mouseout",O,{passive:!0});document.addEventListener("click",e=>{setTimeout(()=>z(e),0)},!0);window.addEventListener("scroll",H,{passive:!0});window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",()=>{i&&a&&(d(),setTimeout(()=>{g();const e=h();e&&p(e)},100))});chrome.runtime.onMessage.addListener((e,n,t)=>{switch(e.type){case"GET_SELECTED_TEXT":{const o=window.getSelection()?.toString()||"";t({text:o});break}case"HIDE_TOOLBAR":{d(),t({success:!0});break}}return!0});console.log("AIMO content script loaded");
//# sourceMappingURL=content-DjZ1fHPJ.js.map
